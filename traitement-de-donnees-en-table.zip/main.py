from mesfonctions import table

champs, table = table("table_csv_ou_txt/pays_du_monde.csv")

for i in range(len(table)):
  table[i][2] = float(table[i][2])  # transforme la cdc en float
  table[i][3] = int(table[i][3])    # transforme la cdc en int

indices = [champs.index("Nom"), champs.index("Continent"), champs.index("Population")]  #position dans la liste ligne

rep = []
for ligne in table:
  if ligne[indices[1]] == "Europe" and ligne[indices[2]] > 5000000:  #1 et 2 correspond à l'indice de la lsite indices
    rep.append(ligne[indices[0]])

print(rep)  # réponse : autriche


