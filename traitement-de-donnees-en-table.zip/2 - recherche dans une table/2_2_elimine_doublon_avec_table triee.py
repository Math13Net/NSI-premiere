from mesfonctions import table, sans_doublons_1

champs, table = table("table_csv_ou_txt/pays_du_monde_doublon_trie.csv")

table_propre = sans_doublons_1(table, 0)

print(table)
print(table_propre)