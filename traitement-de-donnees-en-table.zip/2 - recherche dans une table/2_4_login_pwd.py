# créer une fonction login() qui demande à l'utilisateur
# son login et son pwd
# puis recherche dans le fichier users.txt
# et répond en fonction
# login# wrong login
# wrong pwd

# à vous de jouer

