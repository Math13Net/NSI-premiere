f = open("table_csv_ou_txt/pays_du_monde.csv", "r")
table_1 =[ligne.rstrip().split(";") for ligne in f]
f.close()

print(type(table_1)) # table est une liste de liste
print(table_1)

# noter que la première ligne sont les en-têtes
# toutes les informations sont au format <str>
