f = open("table_csv_ou_txt/pays_du_monde.csv", "r")

champs = f.readline()  # lecture de la 1ere ligne
champs = champs.rstrip().split(";")  # et prépare la liste champs

lignes = f.readlines()  # lecture de toutes les lignes (ligne par ligne)
table = []
for ligne in lignes:
  liste = ligne.rstrip().split(";")
  liste[2] = float(liste[2])
  liste[3] = int(liste[3])
  table.append(liste)  # ou table.append(tuple(liste))
f.close()

print(table)

