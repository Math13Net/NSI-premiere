f = open("table_csv_ou_txt/pays_du_monde.csv", "r")
table_2 =[tuple(ligne.rstrip().split(";")) for ligne in f]
f.close()

print(type(table_2)) # table est une liste de tuple
print(table_2)

# noter que la première ligne sont les en-têtes
# toutes les informations sont au format <str>