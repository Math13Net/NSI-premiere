from mesfonctions import ajout, table

champs_a, table_a = table("table_csv_ou_txt/pays_du_monde_doublon_trie.csv")
champs_b, table_b = table("table_csv_ou_txt/pays_du_monde_doublon_non_trie.csv")

concatenation = ajout(table_a,table_b,champs_a)

print(concatenation)