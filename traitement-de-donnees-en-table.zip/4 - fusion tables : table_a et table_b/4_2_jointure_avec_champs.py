from mesfonctions import fusion, table

champs_a, table_a = table("table_csv_ou_txt/fusion_table_a.csv")
champs_a, table_b = table("table_csv_ou_txt/fusion_table_b.csv")

table_fusion = fusion(table_a, 0, table_b, 1)

print(table_a)
print(table_b)
print(table_fusion)