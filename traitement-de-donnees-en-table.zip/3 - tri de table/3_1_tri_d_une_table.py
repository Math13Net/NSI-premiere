# récupérer les indices du tri
indices = [champs.index("Nom"), champs.index("Population")]

# on effectue le tri, par exemple avec sorted()
tri = sorted(table, key=lamda ligne: ligne[indices[1]], reverse=True)

# on construit la liste reponse
rep = []
for ligne in tri:
  rep.append([tri[indices[0]]], [tri[indices[1]]])