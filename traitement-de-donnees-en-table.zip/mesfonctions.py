# les fonctions utilisées dans ce projet

def sans_doublons_1(table, indice):
  """ élimine les doublons d'une table
  premier cas : la table est trié suivant les noms"""
  rep = [table[0]]
  for ligne in table:
    if ligne[indice] != rep[-1][indice]:
      rep.append(ligne)
  return rep

def sans_doublons_2(table, indice):
  """ élimine les doublons d'une table
  deuxième cas : cas général"""
  rep = [table[0]]
  for i in range(1, len(table)):
    test = True
    ligne = table[i]
    valeur = ligne[indice]
    for j in range(len(rep)):
      if rep[j][indice] == valeur:
        test = False
        break  # pas obligatoire mais évite de parcourir la liste
    if test:
      rep.append(ligne)
  return rep

def ajout(table_1, table_2, indice):
  """ permet de concaténer 2 tables
  attention : les tables ont les mêmes champs dans le même ordre
  avec les mêmes domaines de valeurs"""
  rep = table_1 + table_2
  return rep

def fusion(table1, i1, table2, i2):
  """ construction d'une nouvelle table à partir de 2 autres
  ayant un champ commun, l'une à l'indice i1, l'autre à i2 """
  from copy import deepcopy

  rep = deepcopy(table1)   # à importer depuis le module copy
  for ligne1 in rep:
    for ligne2 in table2:
      if ligne1[i1] == ligne2[i2]:
        for i in range(len(ligne2)):
          if i != i2:
            ligne1.append(ligne2[i])
  return rep

def table(fichier):
  """ à partir d'un fichier .csv
  fournie champs, table """
  f = open(fichier, "r")
  champs = f.readline()
  champs = champs.rstrip().split(";")
  lignes = f.readlines()
  table = []
  for ligne in lignes:
    liste = ligne.rstrip().split(";")
    table.append(liste)
  f.close()
  return champs, table


# SOLUTION
#--------------------------------------------
def login():
  username = input("What is your username : ")
  password = input("What is your password : ")

  newfile = open("table_csv_ou_txt/users.txt","r")
  users_2D = eval(newfile.read())
  newfile.close()

  found = False
  for count in range(len(users_2D)):
    if username == users_2D[count][0]:
      found = True
      if password == users_2D[count][1]:
        print("logged in")
      else:
        print("incorrect password")
        login()
    else:
      found == False
      print("Invalid username")
      login()
